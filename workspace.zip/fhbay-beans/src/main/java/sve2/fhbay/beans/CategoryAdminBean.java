package sve2.fhbay.beans;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import sve2.fhbay.domain.Category;
import sve2.fhbay.interfaces.CategoryAdminLocal;
import sve2.fhbay.interfaces.CategoryAdminRemote;
import sve2.fhbay.interfaces.dao.CategoryDao;

@Stateless
public class CategoryAdminBean implements CategoryAdminLocal, CategoryAdminRemote{
	
	@EJB
	private CategoryDao categoryDao;
	
	@Override
	public Long saveCategory(Category category) {
		System.out.println("fuck you");
		categoryDao.persist(category);
		return category.getId();
	}
}
