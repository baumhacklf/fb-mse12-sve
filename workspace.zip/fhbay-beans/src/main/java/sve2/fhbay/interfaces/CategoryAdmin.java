package sve2.fhbay.interfaces;

import sve2.fhbay.domain.Category;

public interface CategoryAdmin {
	Long saveCategory(Category category);
}
