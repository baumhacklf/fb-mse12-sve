package sve2.fhbay.interfaces;

import javax.ejb.Local;

@Local
public interface CategoryAdminLocal extends CategoryAdmin {

}
