package sve2.fhbay.interfaces;

import javax.ejb.Remote;

@Remote
public interface CategoryAdminRemote extends CategoryAdmin {

}
