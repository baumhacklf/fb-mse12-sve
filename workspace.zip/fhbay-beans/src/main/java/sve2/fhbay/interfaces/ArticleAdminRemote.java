package sve2.fhbay.interfaces;

import javax.ejb.Remote;

@Remote
public interface ArticleAdminRemote extends ArticleAdmin {

}
