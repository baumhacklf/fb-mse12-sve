package sve2.fhbay.interfaces;

import javax.ejb.Local;

@Local
public interface ArticleAdminLocal extends ArticleAdmin {

}
