package sve2.fhbay.interfaces;

public interface Auction {
	// placeBid()
	// getBidInfo()
}
