package sve2.fhbay.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Category implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long id;
	private String name;

//	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, optional = true)
//	private Category parentCategoryId;
//
//	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
//	private Set<Category> subCategories = new HashSet<Category>();
	
	public Category() {
		
	}

	public Category(String name) {
		System.out.println("shit");
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
//
//	public Category getParentCategoryId() {
//		return parentCategoryId;
//	}
//
//	public void setParentCategoryId(Category parentCategoryId) {
//		this.parentCategoryId = parentCategoryId;
//	}
//
//	public Set<Category> getSubCategories() {
//		return subCategories;
//	}
//
//	public void setSubCategories(Set<Category> subCategories) {
//		this.subCategories = subCategories;
//	}
//
//	/*
//	 * Comfort Method
//	 */
//	public void addSubCategory(Category category) {
//		subCategories.add(category);
//	}

}
