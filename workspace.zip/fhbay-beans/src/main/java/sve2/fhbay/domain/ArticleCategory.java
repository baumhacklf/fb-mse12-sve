package sve2.fhbay.domain;

import java.util.Set;

public class ArticleCategory {
	private Category category;
	private Set<Article> article;

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<Article> getArticle() {
		return article;
	}

	public void setArticle(Set<Article> article) {
		this.article = article;
	}
}
