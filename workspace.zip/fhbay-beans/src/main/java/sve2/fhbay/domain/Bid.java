package sve2.fhbay.domain;

public class Bid {
	private Long id;
	private double amount;
	private Customer bidder;
	private Article article;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Customer getBidder() {
		return bidder;
	}
	public void setBidder(Customer bidder) {
		this.bidder = bidder;
	}
	public Article getArticle() {
		return article;
	}
	public void setArticle(Article article) {
		this.article = article;
	}
}
