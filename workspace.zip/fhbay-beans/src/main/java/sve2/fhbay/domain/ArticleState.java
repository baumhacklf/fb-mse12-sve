package sve2.fhbay.domain;

public enum ArticleState {
  OFFERED, SOLD, UNSALEABLE;
}